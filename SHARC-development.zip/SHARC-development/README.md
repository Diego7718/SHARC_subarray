# SHARC
Welcome to SHARC, a simulator for use in SHARing and Compatibility studies of radiocommunication systems. The development of this software is being lead by the Telecommunications Regulatory Authority (TRA) of Brazil, ANATEL, and it implements the framework proposed by Recommendation ITU-R M.2101 for "modelling and simulation of IMT networks and systems for use in sharing and compatibility studies".

Please refer to `CONTRIBUTING.md` for contribution guidelines and how to setup your environment.