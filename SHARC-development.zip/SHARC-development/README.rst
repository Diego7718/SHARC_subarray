===============================
SHARC
===============================


.. image:: https://img.shields.io/pypi/v/sharc.svg
        :target: https://pypi.python.org/pypi/sharc

.. image:: https://img.shields.io/travis/edgar-souza/sharc.svg
        :target: https://travis-ci.org/edgar-souza/sharc

.. image:: https://readthedocs.org/projects/sharc/badge/?version=latest
        :target: https://sharc.readthedocs.io/en/latest/?badge=latest
        :alt: Documentation Status

.. image:: https://pyup.io/repos/github/edgar-souza/sharc/shield.svg
     :target: https://pyup.io/repos/github/edgar-souza/sharc/
     :alt: Updates


Simulator for use in sharing and compatibility studies of radio communication systems.


* Free software: GNU General Public License v3
* Documentation: https://sharc.readthedocs.io.


Features
--------

* TODO

Credits
---------

This package was created with Cookiecutter_ and the `audreyr/cookiecutter-pypackage`_ project template.

.. _Cookiecutter: https://github.com/audreyr/cookiecutter
.. _`audreyr/cookiecutter-pypackage`: https://github.com/audreyr/cookiecutter-pypackage

