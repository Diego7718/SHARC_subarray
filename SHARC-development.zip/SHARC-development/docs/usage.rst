=====
Usage
=====

To use SHARC in a project::

    import sharc
