# IMT Hotspot EESS Active Campaign

This campaign's objective is to try and replicate Luciano's contribution 20.

Using the script `plot_results.py` automatically aggregates results and compares it to Luciano's INR results in
contrib 20

The document that should be referenced is
"HIBS and IMT-2020 Coexistence with other Space/Terrestrial
Communications and Radar Systems", a Doctoral Thesis by Luciano Camilo Alexandre publicated on Dec 2022

The document can be downloaded found [here](https://www2.inatel.br/biblioteca/teses-de-doutorado)
and
[downloaded here](https://biblioteca.inatel.br/cict/acervo%20publico/sumarios/Teses%20de%20Doutorado%20do%20Inatel/Luciano%20Camilo%20Alexandre.pdf)

