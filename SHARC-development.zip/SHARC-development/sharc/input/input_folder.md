# Input folder
This folder holds reference parameter files used for root level campaigns or parameters used as reference
for campaign level simulations.