"""Commom SHARC definitions"""
SHARC_IMPLEMENTED_SYSTEMS = [
    "EESS_SS",
    "METSAT_SS",
    "FSS_SS",
    "FSS_ES",
    "FS",
    "RAS",
    "SINGLE_EARTH_STATION",
]
